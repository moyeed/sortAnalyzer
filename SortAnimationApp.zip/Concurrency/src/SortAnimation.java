/**********************************************************
 *                                                        *
 *  CSCI 470/502        Assignment 7         Summer 2021  *
 *                                                        *
 *                                                        *
 *  Developer(s) :  Mohammed Abdul Moyeed                 *
 *                                                        *
 *                                                        *
 *  Due Date/Time: Thursday, 08/05/2021 11:59 PM          *
 *                                                        *
 *  Purpose:  This class encapsulates                     *
 *               the controller logic of the app          * 
 *                                                        *
 **********************************************************/
import javafx.application.Platform;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Line;

public class SortAnimation implements Runnable {
    protected boolean doneSorting; 
    private String algo;
    private int[] data;
    protected AnchorPane areaToUpdate;
    protected Thread otherThread;
    protected Button sortButton;
    protected Button populateButton;
    private String speedSelection;

    public SortAnimation(String algo, int[] data, AnchorPane areaToUpdate, Button sortButton,Button populaButton,String speedSelection){ //,GridPane root
        this.algo =  algo;
        this.data = data;
        this.areaToUpdate = areaToUpdate;
        this.sortButton =sortButton;
        this.populateButton = populaButton;
        this.speedSelection = speedSelection;
    }
    public void run(){
        this.doneSorting = (this.algo == "Selection")?(selectionSort(this.data)):
                    (this.algo == "Insertion")?(InsertionSort(this.data)):(quickSort(this.data, 0, this.data.length-1));  
        if(!this.otherThread.isAlive())
            Platform.runLater(() ->{
                this.sortButton.setText("Sort");
                this.sortButton.setDisable(true);
                this.populateButton.setDisable(false);
            });
            
     }

     void modifyDisplay(int [] data) {
        Line[] lines = new Line[data.length];
        for(int i = 0; i < data.length;i++){
            Line newLine = new Line(data.length-i-1, data.length-1, data.length-i-1, data[i]);
            lines[i] = newLine;
        }
        Platform.runLater(() ->{
            this.areaToUpdate.getChildren().clear(); 
            this.areaToUpdate.getChildren().addAll(lines);
            
        });
        try {
           long sleepTime = (this.speedSelection == "Slow")?(120):((this.speedSelection == "Medium")?(60):(30));
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        while(SortAnimationController.pause == true)
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
     }

     boolean selectionSort(int arr[]){
        int n = arr.length;
 
        // One by one move boundary of unsorted subarray
        for (int i = 0; i < n-1; i++)
        {
            // Find the minimum element in unsorted array
            int min_idx = i;
            for (int j = i+1; j < n; j++)
                if (arr[j] < arr[min_idx])
                    min_idx = j;
 
            // Swap the found minimum element with the first
            // element
            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
            modifyDisplay(arr);

        }
        return true;
    }

    boolean InsertionSort(int arr[]){
        int n = arr.length;
        for (int i = 1; i < n; ++i) {
            int key = arr[i];
            int j = i - 1;
 
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
             modifyDisplay(arr);
        }
        return true;
    }

    boolean quickSort(int[] arr, int low, int high){
        if (low < high)
        {
            // pi is partitioning index, arr[p]
            // is now at right place
            int pi = partition(arr, low, high);
    
            // Separately sort elements before
            // partition and after partition
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
            modifyDisplay(arr);
        }
        return true;
    }

    int partition(int[] arr, int low, int high){
        // pivot
        int pivot = arr[high];
        
        // Index of smaller element and
        // indicates the right position
        // of pivot found so far
        int i = (low - 1);
    
        for(int j = low; j <= high - 1; j++)
        {
            
            // If current element is smaller
            // than the pivot
            if (arr[j] < pivot)
            {
                
                // Increment index of
                // smaller element
                i++;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, high);
        return (i + 1);
    }

    void swap(int[] arr, int i, int j){
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
}
