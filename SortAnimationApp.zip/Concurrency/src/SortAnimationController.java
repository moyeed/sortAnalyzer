/**********************************************************
 *                                                        *
 *  CSCI 470/502        Assignment 7         Summer 2021  *
 *                                                        *
 *                                                        *
 *  Developer(s) :  Mohammed Abdul Moyeed                 *
 *                                                        *
 *                                                        *
 *  Due Date/Time: Thursday, 08/05/2021 11:59 PM          *
 *                                                        *
 *  Purpose:  This class encapsulates                     *
 *               the Graphical user interface of          *
 *               the app.                                 *
 *                                                        *
 **********************************************************/

import java.util.Random;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.shape.Line;


public class SortAnimationController extends Application {

    @FXML
    protected AnchorPane leftArea;

    @FXML
    protected ComboBox<String> sortSelectionLeft;

    @FXML
    protected AnchorPane rightArea;

    @FXML
    protected ComboBox<String> sortSelectionRight;

    @FXML
    protected ComboBox<String> speedDropDownButton;

    @FXML
    protected Button sortButton;

    @FXML
    protected Button populateButton;


    protected int[] dataToSort;

    protected static boolean pause;

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader  = new FXMLLoader();
        loader.setLocation(getClass().getResource("SortAnimationController.fxml"));
        GridPane root = loader.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Sorting Animation");
        stage.show();
    }

    public void initialize() {
        String[] speedArray = {"Slow","Medium","Fast"};
        String[] AlgoArray = {"Selection","Insertion","Quick"};
        this.speedDropDownButton.getItems().clear();
        this.sortSelectionRight.getItems().clear();
        this.sortSelectionLeft.getItems().clear();

        for(String speed : speedArray){
            this.speedDropDownButton.getItems().add(speed);
        }

        for(String sortAlgo : AlgoArray){
            this.sortSelectionRight.getItems().add(sortAlgo);
            this.sortSelectionLeft.getItems().add(sortAlgo);
        }

        this.speedDropDownButton.getSelectionModel().selectFirst();
        this.sortSelectionRight.getSelectionModel().selectFirst();
        this.sortSelectionLeft.getSelectionModel().selectFirst();

        this.sortButton.setDisable(true);
    }

    @FXML
    void onPopulateClicked(ActionEvent event) {
        this.cleaarBothPanes();
        int width = Math.min((int)this.leftArea.getWidth(),(int)this.rightArea.getWidth());
        int height = Math.min((int)this.leftArea.getHeight(),(int)this.rightArea.getHeight());
        int[] dataToSort = new int[width];
        Random random = new Random();
        for(int i = 0; i <dataToSort.length;i++){
            dataToSort[i] = random.nextInt(height);
            this.insertLinesInPaLine(i, width, i, dataToSort[i]);
        }
        this.dataToSort = dataToSort;
        this.populateButton.setDisable(true);
        this.sortButton.setDisable(false);
    }

    @FXML
    void onSortClicked(ActionEvent event) {
        if(this.sortButton.getText().equalsIgnoreCase("sort")){
            this.sortButton.setText("Pause");
            String leftSortAlgo = this.sortSelectionLeft.getSelectionModel().getSelectedItem();
            String rightSortAlgo = this.sortSelectionRight.getSelectionModel().getSelectedItem();
            String speedSelection = this.speedDropDownButton.getSelectionModel().getSelectedItem();
            SortAnimation sortAnimationLeft = new SortAnimation(leftSortAlgo,this.dataToSort.clone(), this.leftArea, this.sortButton,this.populateButton,speedSelection);
            SortAnimation sortAnimationRight = new SortAnimation(rightSortAlgo,this.dataToSort.clone(),this.rightArea, this.sortButton,this.populateButton,speedSelection);
            Thread leftThread = new Thread(sortAnimationLeft);
            Thread rigThread = new Thread(sortAnimationRight);
            sortAnimationLeft.otherThread = rigThread;
            sortAnimationRight.otherThread = leftThread;
            leftThread.start();
            rigThread.start();

        }
        else if(this.sortButton.getText() == "Pause"){
            this.sortButton.setText("Resume");
            SortAnimationController.pause = true;
        }
        else if(this.sortButton.getText() == "Resume"){
            this.sortButton.setText("Pause");
            SortAnimationController.pause = false;
        }
        else
            this.sortButton.setText("Sort");
    
    }

    void cleaarBothPanes(){
        this.rightArea.getChildren().clear();
        this.leftArea.getChildren().clear();
    }

    void insertLinesInPaLine(int x1,int y1,int x2,int y2){
        Line newLine1 = new Line(x1,y1,x2,y2);
        Line newLine2 = new Line(x1,y1,x2,y2);
        this.rightArea.getChildren().add(newLine1);
        this.leftArea.getChildren().add(newLine2); 
    }

}
